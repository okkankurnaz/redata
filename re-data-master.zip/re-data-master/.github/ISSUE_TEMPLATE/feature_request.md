---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE]"
labels: ''
assignees: ''

---

**Tell us about the problem you're trying to solve**

What are you trying to do?

**Describe the solution you’d like**

A clear and concise description of what you want to see happen.

**Describe the alternative you’ve considered or used**
