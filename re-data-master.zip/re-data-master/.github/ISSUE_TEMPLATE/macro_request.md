---
name: Macro request
about: Suggest an idea for this project
title: "[MACRO]"
labels: ''
assignees: ''

---

**What type of re_data dbt macro you would like to add**

Currently re_data have 5 types of macros to:

 - filter
 - normalize
 - validate
 - clean
 - compute metric
 
Choose one of them or suggest a new type if desired.

**What macro should be doing**

**Describe your current solution to this, if any**

