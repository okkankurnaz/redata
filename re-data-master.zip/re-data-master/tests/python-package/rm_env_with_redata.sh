rm -rf test_re_data
pyenv virtualenv-delete --force test_re_data
