import os

PACKAGE_PATH = os.path.dirname(__file__)

OVERVIEW_INDEX_FILE_PATH = os.path.normpath(
    os.path.join(PACKAGE_PATH, "index.html"))