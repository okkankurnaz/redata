declare module 'vis-network-react';
