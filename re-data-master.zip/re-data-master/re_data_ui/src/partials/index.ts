/* eslint-disable import/prefer-default-export */
export { default as TestsPartial } from './Tests';
export { default as GraphPartial } from './Graph';
